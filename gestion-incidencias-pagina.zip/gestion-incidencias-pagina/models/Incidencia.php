<?php

require_once __DIR__ . '/../config/database.php';

class Incidencia {

    private $db;
    private $map;

    public function __construct() {
        $this->db = Database::connect();
        $this->map = require __DIR__ . '/../config/model_map.php';
    }

    public function getAll() {
        $table = $this->map['incidencia_table'];
        $stmt = $this->db->query("SELECT * FROM $table");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getByCreator($username) {
        $table = $this->map['incidencia_table'];

        if (!isset($this->map['incidencia_creator_username'])) {
            // Si no hi ha camp configurat per al creador, retorna totes
            return $this->getAll();
        }

        $creatorField = $this->map['incidencia_creator_username'];

        $stmt = $this->db->prepare("SELECT * FROM $table WHERE $creatorField = ?");
        $stmt->execute([$username]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find($id) {
        $table = $this->map['incidencia_table'];
        $idField = $this->map['incidencia_id'];

        $stmt = $this->db->prepare("SELECT * FROM $table WHERE $idField = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($data) {
        $table = $this->map['incidencia_table'];
        $estat = $this->map['incidencia_estat'];
        $descripcio = $this->map['descripcio_Incidencia'];
        $assumpte = $this->map['assumpte_Incidencia'];
        $dataApertura = $this->map['data_Apertura_Incidencia'];

        $creatorUsernameField = $this->map['incidencia_creator_username'] ?? null;
        $creatorNameField = $this->map['incidencia_creator_name'] ?? null;

        $columns = [$assumpte, $estat, $descripcio, $dataApertura];
        $values = [
            $data['assumpte_Incidencia'],
            $data['estat'],
            $data['descripcio_Incidencia'],
            date('Y-m-d H:i:s')
        ];

        if ($creatorUsernameField && !empty($data['creator_username'] ?? null)) {
            $columns[] = $creatorUsernameField;
            $values[] = $data['creator_username'];
        }

        if ($creatorNameField && !empty($data['creator_name'] ?? null)) {
            $columns[] = $creatorNameField;
            $values[] = $data['creator_name'];
        }

        $columnsSql = implode(', ', $columns);
        $placeholders = implode(', ', array_fill(0, count($values), '?'));

        $stmt = $this->db->prepare(
            "INSERT INTO $table ($columnsSql) VALUES ($placeholders)"
        );

        return $stmt->execute($values);
    }

    public function updateStatus($id, $nouEstat) {
        $table = $this->map['incidencia_table'];
        $idField = $this->map['incidencia_id'];
        $estatField = $this->map['incidencia_estat'];

        $stmt = $this->db->prepare(
            "UPDATE $table SET $estatField = ? WHERE $idField = ?"
        );

        return $stmt->execute([$nouEstat, $id]);
    }
}