<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detall Incidència</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h2>Detall Incidència</h2>

<p><strong>ID:</strong> <?= htmlspecialchars($incidencia['id_Incidencia']) ?></p>
<?php if (!empty($incidencia['nom_Creador'] ?? null)): ?>
    <p><strong>Client:</strong> <?= htmlspecialchars($incidencia['nom_Creador']) ?></p>
<?php endif; ?>
<p><strong>Estat:</strong> <?= htmlspecialchars($incidencia['estat_Incidencia']) ?></p>
<p><strong>Descripció:</strong> <?= htmlspecialchars($incidencia['descripcio_Incidencia']) ?></p>

<h3>Historial de comentaris</h3>

<?php if (!empty($historial)): ?>
    <ul>
        <?php foreach ($historial as $entrada): ?>
            <li>
                <strong><?= htmlspecialchars($entrada['data_Canvi_Historial']) ?></strong><br>
                <?php if (!empty($entrada['comentaris_Historial'])): ?>
                    <?= nl2br(htmlspecialchars($entrada['comentaris_Historial'])) ?>
                <?php else: ?>
                    <em>Sense comentaris</em>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p><em>Encara no hi ha comentaris per aquesta incidència.</em></p>
<?php endif; ?>

<?php $isTecnico = $_SESSION['is_tecnic'] ?? false; ?>

<h3>Afegir comentari</h3>
<form method="POST" action="index.php?action=add_comment&id=<?= urlencode($incidencia['id_Incidencia']) ?>">
    <?php if ($isTecnico): ?>
        <label>Canviar estat:</label>
        <select name="nou_estat">
            <option value="">-- Mantindre estat actual (<?= htmlspecialchars($incidencia['estat_Incidencia']) ?>) --</option>
            <option value="Oberta" <?= $incidencia['estat_Incidencia'] === 'Oberta' ? 'selected' : '' ?>>Oberta</option>
            <option value="En Procés" <?= $incidencia['estat_Incidencia'] === 'En Procés' ? 'selected' : '' ?>>En Procés</option>
            <option value="Resolta" <?= $incidencia['estat_Incidencia'] === 'Resolta' ? 'selected' : '' ?>>Resolta</option>
            <option value="Tancada" <?= $incidencia['estat_Incidencia'] === 'Tancada' ? 'selected' : '' ?>>Tancada</option>
        </select>
        <br><br>
    <?php endif; ?>
    <textarea name="comentaris_Historial" rows="4" cols="50" required></textarea><br><br>
    <button type="submit">Afegir comentari</button>
</form>

<a href="index.php">Tornar</a>
</div>
</body>
</html>