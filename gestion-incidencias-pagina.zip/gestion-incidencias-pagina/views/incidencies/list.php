<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Llista d'Incidències</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h2>Llista d'Incidències</h2>

<a href="index.php?action=create">Nova incidència</a>

<ul>
<?php foreach ($incidencies as $i): ?>
    <li>
        <a href="index.php?action=show&id=<?= $i['id_Incidencia'] ?>">
            <?= htmlspecialchars($i['id_Incidencia']) ?> - <?= htmlspecialchars($i['assumpte_Incidencia']) ?>
        </a>
    </li>
<?php endforeach; ?>
</ul>
</div>
</body>
</html>