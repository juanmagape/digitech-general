<?php

return [
    'incidencia_table' => 'INCIDENCIES',
    'incidencia_id' => 'id_Incidencia',
    'incidencia_estat' => 'estat_Incidencia',
    'descripcio_Incidencia' => 'descripcio_Incidencia',
    'assumpte_Incidencia' => 'assumpte_Incidencia',
    'data_Apertura_Incidencia' => 'data_Apertura_Incidencia',
    // Campos para identificar el creador de la incidència
    // Asegúrate de que existan en la taula INCIDENCIES:
    //   - usuari_Creador (login / usuari de Windows)
    //   - nom_Creador (nom i cognoms del client)
    'incidencia_creator_username' => 'usuari_Creador',
    'incidencia_creator_name' => 'nom_Creador',

    'tecnic_table' => 'TECNICS',
    'tecnic_id' => 'id_Tecnic',
    'tecnic_nom' => 'nom_Tecnic',

    'client_table' => 'CLIENTS',
    'client_id' => 'id_Client',
    'client_nom' => 'nom',

    'historial_table' => 'HISTORIAL',
    'historial_id' => 'id_Historial',
    'historial_estats_anteriors' => 'estats_Anteriors_Historial',
    'historial_data_canvi' => 'data_Canvi_Historial',
    'historial_comentaris' => 'comentaris_Historial',
    'historial_incidencia_id' => 'id_Incidencia'
];