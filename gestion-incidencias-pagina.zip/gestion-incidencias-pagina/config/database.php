<?php

class Database {

    public static function connect() {
        return new PDO(
            "mysql:host=192.168.10.6;dbname=gestio_incidencies;charset=utf8",
            "usuario", // Cambia el usuario si tu servidor no usa 'root'
            "digitech",     // Cambia la contraseña si tu servidor tiene password
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]
        );
    }
}