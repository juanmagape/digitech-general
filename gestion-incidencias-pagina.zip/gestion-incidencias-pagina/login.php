<?php
putenv('LDAPTLS_REQCERT=never');
session_start();

require_once __DIR__ . '/config/database.php';
$modelMap = require __DIR__ . '/config/model_map.php';

$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['username'];
    $password = $_POST['password'];

    $server = 'ldaps://phoenixtech-g1.local'; 
    $dominio_ad = '@phoenixtech-g1.local'; 

    $conn = ldap_connect($server);

    if ($conn) {
        ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($conn, LDAP_OPT_REFERRALS, 0);

        $bind = @ldap_bind($conn, $usuario . $dominio_ad, $password);

        if ($bind) {
            // Login correcte a LDAP
            $_SESSION['usuario_logeado'] = $usuario;
            // De moment, usem el mateix valor com a nom visible
            $_SESSION['display_name'] = $usuario;

            // Detectar si és tècnic o client segons les taules de BD
            $db = Database::connect();

            // Per defecte, assumim que és usuari (client)
            $_SESSION['is_tecnic'] = false;

            // Comprovar si està a la taula de tècnics
            $stmt = $db->prepare(
                "SELECT {$modelMap['tecnic_id']} FROM {$modelMap['tecnic_table']} WHERE {$modelMap['tecnic_nom']} = ? LIMIT 1"
            );
            $stmt->execute([$usuario]);
            $tecnic = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($tecnic) {
                $_SESSION['is_tecnic'] = true;
                $_SESSION['tecnic_id'] = $tecnic[$modelMap['tecnic_id']];
            } else {
                // Si no és tècnic, intentem trobar-lo com a client
                $stmt = $db->prepare(
                    "SELECT {$modelMap['client_id']}, {$modelMap['client_nom']} FROM {$modelMap['client_table']} WHERE {$modelMap['client_nom']} = ? LIMIT 1"
                );
                $stmt->execute([$usuario]);
                $client = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($client) {
                    $_SESSION['client_id'] = $client[$modelMap['client_id']];
                    // Si hi ha nom complet, l'usem com a display name
                    if (!empty($client[$modelMap['client_nom']])) {
                        $_SESSION['display_name'] = $client[$modelMap['client_nom']];
                    }
                }
            }

            header("Location: index.php");
            exit();
        } else {
            $mensaje = "<p style='color: red;'>Usuario o contraseña incorrectos.</p>";
        }
        
        ldap_unbind($conn);
    } else {
        $mensaje = "<p style='color: red;'>No se pudo conectar al servidor LDAP.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <h2>Inici de Sessió</h2>
        <?php echo $mensaje; ?>
        <form method="POST" action="">
            <label for="username">Usuari:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Contrasenya:</label>
            <input type="password" id="password" name="password" required>

            <input type="submit" value="Entrar">
        </form>
    </div>
</body>
</html>