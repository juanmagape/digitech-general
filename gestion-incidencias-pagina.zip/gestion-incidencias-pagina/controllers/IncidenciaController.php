<?php

require_once __DIR__ . '/../models/Incidencia.php';
require_once __DIR__ . '/../models/Historial.php';

class IncidenciaController {

    public function index() {
        $model = new Incidencia();
        $isTecnico = $_SESSION['is_tecnic'] ?? false;

        if ($isTecnico) {
            // Els tècnics veuen totes les incidències
            $incidencies = $model->getAll();
        } else {
            // Els usuaris només veuen les seues incidències
            $username = $_SESSION['usuario_logeado'] ?? null;
            if ($username !== null) {
                $incidencies = $model->getByCreator($username);
            } else {
                $incidencies = $model->getAll();
            }
        }
        require __DIR__ . '/../views/incidencies/list.php';
    }

    public function show($id) {
        $incidenciaModel = new Incidencia();
        $historialModel = new Historial();

        $incidencia = $incidenciaModel->find($id);
        $historial = $historialModel->getByIncidencia($id);

        require __DIR__ . '/../views/incidencies/show.php';
    }

    public function create() {
        require __DIR__ . '/../views/incidencies/create.php';
    }

    public function store() {
        $model = new Incidencia();
        $data = $_POST;

        // Guardar qui és el creador de la incidència
        if (session_status() === PHP_SESSION_ACTIVE) {
            if (isset($_SESSION['usuario_logeado'])) {
                $data['creator_username'] = $_SESSION['usuario_logeado'];
            }

            if (isset($_SESSION['display_name'])) {
                $data['creator_name'] = $_SESSION['display_name'];
            } elseif (isset($_SESSION['usuario_logeado'])) {
                $data['creator_name'] = $_SESSION['usuario_logeado'];
            }
        }

        $model->create($data);
        header("Location: index.php");
        exit;
    }

    public function addComment($id) {
        $incidenciaModel = new Incidencia();
        $historialModel = new Historial();

        $incidencia = $incidenciaModel->find($id);

        if (!$incidencia) {
            header("Location: index.php");
            exit;
        }

        $isTecnico = $_SESSION['is_tecnic'] ?? false;
        $comentaris = $_POST['comentaris_Historial'] ?? '';
        $estatAnterior = $incidencia['estat_Incidencia'] ?? '';
        $nouEstat = $_POST['nou_estat'] ?? null;

        $tindreCanviEstat = false;

        if ($isTecnico && $nouEstat && $nouEstat !== $estatAnterior) {
            // Canviem l'estat de la incidència
            $incidenciaModel->updateStatus($id, $nouEstat);
            $tindreCanviEstat = true;

            $prefix = "Canvi d'estat: " . $estatAnterior . " -> " . $nouEstat . ".";
            if ($comentaris !== '') {
                $comentaris = $prefix . "\n" . $comentaris;
            } else {
                $comentaris = $prefix;
            }
        }

        if ($comentaris !== '' || $tindreCanviEstat) {
            $historialModel->addEntry($id, $estatAnterior, $comentaris);
        }

        header("Location: index.php?action=show&id=" . urlencode($id));
        exit;
    }
}