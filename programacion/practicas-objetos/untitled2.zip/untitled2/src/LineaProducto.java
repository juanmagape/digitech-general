public class LineaProducto extends Producto {

    public LineaProducto(String nombre, double precio, int stock) {
        super(nombre, precio, stock);

        
    }
}
